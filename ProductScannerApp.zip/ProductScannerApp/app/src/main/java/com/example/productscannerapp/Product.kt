package com.example.productscannerapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val sku: String,
    val name: String,
    val price: Double
)
