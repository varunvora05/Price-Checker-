package com.example.productscannerapp

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.productscannerapp.databinding.ActivityMainBinding
import com.example.productscannerapp.databinding.DialogInsertProductBinding
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: ProductDatabase
    private val scannedProducts = mutableListOf<Product>()

    private val TAG = "MainActivity"

    // Activity Result Launcher for ZXing
    private val barcodeLauncher = registerForActivityResult(ScanContract()) { result ->
        try {
            if (result.contents != null) {
                handleScannedProduct(result.contents)
            } else {
                Toast.makeText(this, "Scan cancelled", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling scan result: ${e.message}")
            Toast.makeText(this, "Error processing scan", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)
        } catch (e: Exception) {
            Log.e(TAG, "ViewBinding error: ${e.message}")
            Toast.makeText(this, "UI initialization error", Toast.LENGTH_LONG).show()
            return
        }

        // Initialize Room database safely
        try {
            db = ProductDatabase.getDatabase(this)
        } catch (e: Exception) {
            Log.e(TAG, "Database initialization error: ${e.message}")
            Toast.makeText(this, "Database error", Toast.LENGTH_LONG).show()
            return
        }

        binding.tvResult.text = "No products scanned yet"

        // Button listeners
        binding.btnScan.setOnClickListener {
            try {
                val options = ScanOptions().apply {
                    setPrompt("Scan a product barcode")
                    setBeepEnabled(true)
                    setOrientationLocked(true)
                }
                barcodeLauncher.launch(options)
            } catch (e: Exception) {
                Log.e(TAG, "Scan launch error: ${e.message}")
                Toast.makeText(this, "Error launching scanner", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnStop.setOnClickListener {
            try {
                showScannedProducts()
            } catch (e: Exception) {
                Log.e(TAG, "Show scanned products error: ${e.message}")
                Toast.makeText(this, "Error showing scanned products", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnInsert.setOnClickListener {
            try {
                showInsertDialog()
            } catch (e: Exception) {
                Log.e(TAG, "Insert dialog error: ${e.message}")
                Toast.makeText(this, "Error opening insert dialog", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleScannedProduct(sku: String) {
        lifecycleScope.launch {
            try {
                val product = db.productDao().getProductBySku(sku)
                if (product != null) {
                    scannedProducts.add(product)
                    Toast.makeText(this@MainActivity, "Scanned: ${product.name}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Product not found!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Database error scanning product: ${e.message}")
                Toast.makeText(this@MainActivity, "Error fetching product", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showInsertDialog() {
        val dialogBinding = DialogInsertProductBinding.inflate(layoutInflater)

        AlertDialog.Builder(this)
            .setTitle("Insert Product")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val sku = dialogBinding.etSku.text.toString().trim()
                val name = dialogBinding.etName.text.toString().trim()
                val price = dialogBinding.etPrice.text.toString().toDoubleOrNull() ?: 0.0

                if (sku.isEmpty() || name.isEmpty() || price <= 0.0) {
                    Toast.makeText(this, "Please fill all fields with valid data", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                lifecycleScope.launch {
                    try {
                        db.productDao().insertProduct(Product(sku, name, price))
                        Toast.makeText(this@MainActivity, "Product Saved!", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Log.e(TAG, "Error inserting product: ${e.message}")
                        Toast.makeText(this@MainActivity, "Error saving product", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showScannedProducts() {
        if (scannedProducts.isEmpty()) {
            binding.tvResult.text = "No products scanned yet"
            return
        }

        val text = buildString {
            append("Scanned Products:\n")
            scannedProducts.forEach {
                append("${it.name} - ${it.sku} - ₹${it.price}\n")
            }
        }
        binding.tvResult.text = text
    }
}
